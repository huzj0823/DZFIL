#!/bin/bash
sqlite3 /home/chyd/dzfile/.dzs/meta.db
